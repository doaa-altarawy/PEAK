print.process <- function(x, ...) cat(paste(" ",class(x)[1],": processID=",x$pid,"\n",sep=''))
